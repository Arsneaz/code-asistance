// Compile C++
// g++ -o Test Test.cpp
// Zip Folder
// zip -r Test.zip Files
// Remove Folder
// rm -r Files/...
// Boolean only have 2 value {0, 1}

#include <iostream>
#include <fstream>
#include <cstdio>
#include <string>

using namespace std;

// Setup ur function here -------------------------------------------------------------------

// ------------------------------------------------------------------------------------------

int main()
{
    // Setup filename
    char filename[27];
    int count = 0;
    int check = true;
    int max_file = 5;

    while (check && count < max_file)
    {
        // Opening files
        ofstream input;
        sprintf(filename, "Files/input/input%03i.txt", count);
        input.open(filename);
        if (!input)
        {
            return 1;
        }
        ofstream output;
        sprintf(filename, "Files/output/output%03i.txt", count);
        output.open(filename);
        if (!output)
        {
            return 1;
        }

        printf("Test-case ke %d\n", count++);
        // Insert ur code here --------------------------------------------------------------

        //  Input Section -------------------------------------------------------------------
        cout << "Masukan n: ";
        int n; cin >> n;
        input << n << endl;
        int arr[n];
        for (int i = 0; i < n; i++)
        {
            cin >> arr[i];
            input << arr[i] << " ";
        }

        // Output Section -------------------------------------------------------------------
        cout << "Array yang sudah dibalik" << endl;
        output << "Array yang sudah dibalik" << endl;
        for (int i = n-1; i >= 0; i--)
        {
            cout << arr[i] << " ";
            output << arr[i] << " ";
        }
        // ----------------------------------------------------------------------------------

        cout << endl;
        // Closing Files
        input.close();
        output.close();
        cout << "Again? ";
        cin >> check;
        cout << endl;
    }

    return 0;
}